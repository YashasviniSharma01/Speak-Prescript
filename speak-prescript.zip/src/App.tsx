/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { Mic, MicOff, Printer, User, AlertCircle, CheckCircle2, ClipboardList, Plus, Stethoscope, Activity, ArrowRight, Search, Video, Phone, X, ArrowLeft, Home, AlertTriangle, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
type AppState = 'portal' | 'doctor-onboarding' | 'patient-list' | 'patient-waiting' | 'doctor-dashboard' | 'live-consultation' | 'registration' | 'recording' | 'review-transcript' | 'processing' | 'review' | 'final';
type Language = 'english' | 'hindi' | 'hinglish' | 'marathi';

interface Doctor {
  id: string;
  name: string;
  specialty: string;
  regNo: string;
  address: string;
  isAvailable: boolean;
}

interface PatientRequest {
  id: string;
  patientName: string;
  age: string;
  symptoms: string;
  timestamp: string;
}

interface Drug {
  Name: string;
  Dosage: string;
  Frequency: string;
  Duration: string;
  Instructions: string;
  Warning?: string;
}

interface PrescriptionData {
  Diagnosis: string;
  Drugs: Drug[];
  Warnings: string[];
  FollowUp: string;
}

interface PatientInfo {
  name: string;
  age: string;
  gender: string;
  allergies: string;
  doctorName: string;
  regNo: string;
  address: string;
}

// --- Constants ---
const translations: Record<Language, any> = {
  english: {
    age: 'Age',
    allergies: 'Known Allergies',
    diagnosis: 'Clinical Diagnosis',
    frequency: 'Frequency',
    duration: 'Duration',
    instructions: 'Instructions',
    patientName: 'Patient Name',
    doctorName: "Doctor's Full Name",
    regNo: 'Medical Reg. No.',
    address: 'Clinic/Hospital Address',
    startConsultation: 'Start Consultation',
    medicationPlan: 'Medication Plan',
    warnings: 'Warnings',
    followUp: 'Follow Up',
    prescription: 'Prescription',
    dateOfIssue: 'Date of Issue',
    clinicalSetup: 'Clinical Setup',
    doctorIdentity: "Doctor's Identity",
    patientDetails: 'Patient Details',
    acousticLayer: 'Acoustic Layer Active',
    speakClearly: 'Speak clearly. Capturing Indian accents and Hinglish phrasing.',
    listening: 'Listening... Tap to stop',
    tapToStart: 'Tap to start medical dictation',
    waitingForVoice: 'Waiting for voice input...',
    stopAndPreview: 'Stop & Preview',
    aiStructuring: 'AI is structuring...',
    nerProcessing: 'Performing Named Entity Recognition (NER) on clinical data.',
    reviewData: 'Review Structured Data',
    verifyEdit: 'Verify and edit the AI-extracted prescription details.',
    safetyWarning: 'Safety Layer Warning',
    recordAgain: 'Record Again',
    approvePrescription: 'Approve Prescription',
    printPrescription: 'Print Prescription',
    back: 'Back',
    signature: 'Authorized Medical Signature',
    doctorSignature: "Doctor's Signature",
    newPatient: 'New Patient',
    iAmPatient: 'I am a Patient',
    iAmDoctorLive: 'I am a Doctor (Live)',
    iAmDoctorScribe: 'I am a Doctor (Quick Scribe)',
    findDoctor: 'Find a doctor, book an appointment',
    seeRequests: 'See incoming patient requests',
    voiceTool: 'Jump straight to the Voice Prescription tool',
    availableDoctors: 'Available Doctors',
    requestVideoCall: 'Request Video Call',
    waitingForDoctor: 'Waiting for Doctor...',
    incomingRequests: 'Incoming Requests',
    acceptAndCall: 'Accept & Call',
    backToHome: 'Back to Home',
    searchDoctor: 'Search by name or specialty...',
    liveConsultation: 'Live Consultation',
    miniScribe: 'Mini Scribe',
    endCall: 'End Call',
    doctorOnboarding: 'Doctor Onboarding',
    fullNameSpec: 'Full Name & Specialization',
    medRegNo: 'Medical Registration Number (NMC/MCI)',
    verifyAbha: 'Verify via ABHA / HPR',
    verifying: 'Verifying Identity...',
    verified: 'Doctor Identity Verified',
    enterDashboard: 'Enter Dashboard',
    onboardingDesc: 'Please verify your medical credentials to access the clinical dashboard.',
    gender: 'Gender',
    medicalHistory: 'Known Allergies / Existing Conditions',
    proceedToVoice: 'Proceed to Voice Consultation',
    doctorOnDuty: 'Doctor on Duty'
  },
  hindi: {
    age: 'उम्र',
    allergies: 'ज्ञात एलर्जी',
    diagnosis: 'नैदानिक निदान',
    frequency: 'आवृत्ति',
    duration: 'अवधि',
    instructions: 'निर्देश',
    patientName: 'मरीज का नाम',
    doctorName: 'डॉक्टर का पूरा नाम',
    regNo: 'मेडिकल पंजीकरण संख्या',
    address: 'क्लीनिक/अस्पताल का पता',
    startConsultation: 'परामर्श शुरू करें',
    medicationPlan: 'दवा योजना',
    warnings: 'चेतावनी',
    followUp: 'अगली जांच',
    prescription: 'नुस्खा',
    dateOfIssue: 'जारी करने की तिथि',
    clinicalSetup: 'नैदानिक सेटअप',
    doctorIdentity: 'डॉक्टर की पहचान',
    patientDetails: 'मरीज का विवरण',
    acousticLayer: 'ध्वनिक परत सक्रिय',
    speakClearly: 'साफ बोलें। भारतीय लहजे और हिंग्लिश वाक्यांशों को कैप्चर करना।',
    listening: 'सुन रहा है... रोकने के लिए टैप करें',
    tapToStart: 'मेडिकल डिक्टेशन शुरू करने के लिए टैप करें',
    waitingForVoice: 'आवाज इनपुट की प्रतीक्षा है...',
    stopAndPreview: 'रोकें और पूर्वावलोकन करें',
    aiStructuring: 'AI संरचना कर रहा है...',
    nerProcessing: 'नैदानिक डेटा पर नामित इकाई पहचान (NER) करना।',
    reviewData: 'संरचित डेटा की समीक्षा करें',
    verifyEdit: 'AI द्वारा निकाले गए नुस्खे के विवरण को सत्यापित और संपादित करें।',
    safetyWarning: 'सुरक्षा परत चेतावनी',
    recordAgain: 'फिर से रिकॉर्ड करें',
    approvePrescription: 'नुस्खा स्वीकृत करें',
    printPrescription: 'नुस्खा प्रिंट करें',
    back: 'पीछे',
    signature: 'अधिकृत चिकित्सा हस्ताक्षर',
    doctorSignature: 'डॉक्टर के हस्ताक्षर',
    newPatient: 'नया मरीज',
    iAmPatient: 'मैं एक मरीज हूँ',
    iAmDoctorLive: 'मैं एक डॉक्टर हूँ (लाइव)',
    iAmDoctorScribe: 'मैं एक डॉक्टर हूँ (क्विक स्क्राइब)',
    findDoctor: 'डॉक्टर खोजें, अपॉइंटमेंट बुक करें',
    seeRequests: 'आने वाले मरीज के अनुरोध देखें',
    voiceTool: 'सीधे वॉयस प्रिस्क्रिप्शन टूल पर जाएं',
    availableDoctors: 'उपलब्ध डॉक्टर',
    requestVideoCall: 'वीडियो कॉल का अनुरोध करें',
    waitingForDoctor: 'डॉक्टर की प्रतीक्षा की जा रही है...',
    incomingRequests: 'आने वाले अनुरोध',
    acceptAndCall: 'स्वीकार करें और कॉल करें',
    backToHome: 'मुख्य पृष्ठ पर वापस जाएं',
    searchDoctor: 'नाम या विशेषता द्वारा खोजें...',
    liveConsultation: 'लाइव परामर्श',
    miniScribe: 'मिनी स्क्राइब',
    endCall: 'कॉल समाप्त करें',
    doctorOnboarding: 'डॉक्टर ऑनबोर्डिंग',
    fullNameSpec: 'पूरा नाम और विशेषज्ञता',
    medRegNo: 'मेडिकल पंजीकरण संख्या (NMC/MCI)',
    verifyAbha: 'ABHA / HPR के माध्यम से सत्यापित करें',
    verifying: 'पहचान सत्यापित की जा रही है...',
    verified: 'डॉक्टर की पहचान सत्यापित',
    enterDashboard: 'डैशबोर्ड में प्रवेश करें',
    onboardingDesc: 'क्लिनिकल डैशबोर्ड तक पहुंचने के लिए कृपया अपने मेडिकल क्रेडेंशियल्स सत्यापित करें।'
  },
  marathi: {
    age: 'वय',
    allergies: 'ज्ञात ॲलर्जी',
    diagnosis: 'क्लिनिकल निदान',
    frequency: 'वारंवारता',
    duration: 'कालावधी',
    instructions: 'सूचना',
    patientName: 'रुग्णाचे नाव',
    doctorName: 'डॉक्टरांचे पूर्ण नाव',
    regNo: 'वैद्यकीय नोंदणी क्रमांक',
    address: 'क्लिनिक/रुग्णालयाचा पत्ता',
    startConsultation: 'सल्लामसलत सुरू करा',
    medicationPlan: 'औषध योजना',
    warnings: 'सूचना/धोके',
    followUp: 'पुढील तपासणी',
    prescription: 'औषधोपचार पत्रक',
    dateOfIssue: 'जारी केल्याची तारीख',
    clinicalSetup: 'क्लिनिकल सेटअप',
    doctorIdentity: 'डॉक्टरांची ओळख',
    patientDetails: 'रुग्णाचे तपशील',
    acousticLayer: 'ध्वनिक स्तर सक्रिय',
    speakClearly: 'स्पष्ट बोला. भारतीय उच्चार आणि हिंग्लिश शब्दरचना टिपत आहे.',
    listening: 'ऐकत आहे... थांबवण्यासाठी टॅप करा',
    tapToStart: 'वैद्यकीय डिक्टेशन सुरू करण्यासाठी टॅप करा',
    waitingForVoice: 'आवाज इनपुटची प्रतीक्षा आहे...',
    stopAndPreview: 'थांबवा आणि पूर्वावलोकन करा',
    aiStructuring: 'AI रचना करत आहे...',
    nerProcessing: 'क्लिनिकल डेटावर नेम्ड एंटिटी रिकग्निशन (NER) करत आहे.',
    reviewData: 'संरचित डेटाचे पुनरावलोकन करा',
    verifyEdit: 'AI ने काढलेल्या औषधोपचार तपशीलांची पडताळणी आणि संपादन करा.',
    safetyWarning: 'सुरक्षा स्तर चेतावणी',
    recordAgain: 'पुन्हा रेकॉर्ड करा',
    approvePrescription: 'औषधोपचार पत्रक मंजूर करा',
    printPrescription: 'औषधोपचार पत्रक प्रिंट करा',
    back: 'मागे',
    signature: 'अधिकृत वैद्यकीय स्वाक्षरी',
    doctorSignature: 'डॉक्टरांची स्वाक्षरी',
    newPatient: 'नवीन रुग्ण',
    iAmPatient: 'मी एक रुग्ण आहे',
    iAmDoctorLive: 'मी एक डॉक्टर आहे (लाइव)',
    iAmDoctorScribe: 'मी एक डॉक्टर आहे (क्विक स्क्राइब)',
    findDoctor: 'डॉक्टर शोधा, अपॉइंटमेंट बुक करा',
    seeRequests: 'येणारे रुग्ण विनंत्या पहा',
    voiceTool: 'थेट व्हॉइस प्रिस्क्रिप्शन टूलवर जा',
    availableDoctors: 'उपलब्ध डॉक्टर',
    requestVideoCall: 'व्हिडिओ कॉलची विनंती करा',
    waitingForDoctor: 'डॉक्टरांची प्रतीक्षा करत आहे...',
    incomingRequests: 'येणाऱ्या विनंत्या',
    acceptAndCall: 'स्वीकारा आणि कॉल करा',
    backToHome: 'मुख्यपृष्ठावर परत जा',
    searchDoctor: 'नाव किंवा वैशिष्ट्याद्वारे शोधा...',
    liveConsultation: 'थेट सल्लामसलत',
    miniScribe: 'मिनी स्क्राइब',
    endCall: 'कॉल संपवा',
    doctorOnboarding: 'डॉक्टर ऑनबोर्डिंग',
    fullNameSpec: 'पूर्ण नाव आणि विशेषज्ञता',
    medRegNo: 'वैद्यकीय नोंदणी क्रमांक (NMC/MCI)',
    verifyAbha: 'ABHA / HPR द्वारे सत्यापित करा',
    verifying: 'ओळख सत्यापित करत आहे...',
    verified: 'डॉक्टरांची ओळख सत्यापित झाली',
    enterDashboard: 'डैशबोर्डवर जा',
    onboardingDesc: 'क्लिनिकल डॅशबोर्डवर प्रवेश करण्यासाठी कृपया तुमची वैद्यकीय क्रेडेन्शियल्स सत्यापित करा।'
  },
  hinglish: {
    age: 'Age',
    allergies: 'Known Allergies',
    diagnosis: 'Clinical Diagnosis',
    frequency: 'Frequency',
    duration: 'Duration',
    instructions: 'Instructions',
    patientName: 'Patient Name',
    doctorName: "Doctor's Full Name",
    regNo: 'Medical Reg. No.',
    address: 'Clinic/Hospital Address',
    startConsultation: 'Start Consultation',
    medicationPlan: 'Medication Plan',
    warnings: 'Warnings',
    followUp: 'Follow Up',
    prescription: 'Prescription',
    dateOfIssue: 'Date of Issue',
    clinicalSetup: 'Clinical Setup',
    doctorIdentity: "Doctor's Identity",
    patientDetails: 'Patient Details',
    acousticLayer: 'Acoustic Layer Active',
    speakClearly: 'Speak clearly. Capturing Indian accents and Hinglish phrasing.',
    listening: 'Listening... Tap to stop',
    tapToStart: 'Tap to start medical dictation',
    waitingForVoice: 'Waiting for voice input...',
    stopAndPreview: 'Stop & Preview',
    aiStructuring: 'AI is structuring...',
    nerProcessing: 'Performing Named Entity Recognition (NER) on clinical data.',
    reviewData: 'Review Structured Data',
    verifyEdit: 'Verify and edit the AI-extracted prescription details.',
    safetyWarning: 'Safety Layer Warning',
    recordAgain: 'Record Again',
    approvePrescription: 'Approve Prescription',
    printPrescription: 'Print Prescription',
    back: 'Back',
    signature: 'Authorized Medical Signature',
    doctorSignature: "Doctor's Signature",
    newPatient: 'New Patient',
    iAmPatient: 'I am a Patient',
    iAmDoctorLive: 'I am a Doctor (Live)',
    iAmDoctorScribe: 'I am a Doctor (Quick Scribe)',
    findDoctor: 'Find a doctor, book an appointment',
    seeRequests: 'See incoming patient requests',
    voiceTool: 'Jump straight to the Voice Prescription tool',
    availableDoctors: 'Available Doctors',
    requestVideoCall: 'Request Video Call',
    waitingForDoctor: 'Waiting for Doctor...',
    incomingRequests: 'Incoming Requests',
    acceptAndCall: 'Accept & Call',
    backToHome: 'Back to Home',
    searchDoctor: 'Search by name or specialty...',
    liveConsultation: 'Live Consultation',
    miniScribe: 'Mini Scribe',
    endCall: 'End Call',
    doctorOnboarding: 'Doctor Onboarding',
    fullNameSpec: 'Full Name & Specialization',
    medRegNo: 'Medical Registration Number (NMC/MCI)',
    verifyAbha: 'Verify via ABHA / HPR',
    verifying: 'Verifying Identity...',
    verified: 'Doctor Identity Verified',
    enterDashboard: 'Enter Dashboard',
    onboardingDesc: 'Please verify your medical credentials to access the clinical dashboard.'
  }
};

// --- Mock Data ---
const MOCK_DOCTORS: Doctor[] = [
  { id: '1', name: 'Dr. Ishaan Sharma', specialty: 'Cardiologist', regNo: 'MC-12345', address: 'Apollo Hospitals, New Delhi', isAvailable: true },
  { id: '2', name: 'Dr. Ananya Singh', specialty: 'General Physician', regNo: 'MC-67890', address: 'Max Healthcare, Mumbai', isAvailable: true },
  { id: '3', name: 'Dr. Rahul Mehta', specialty: 'Pediatrician', regNo: 'MC-11223', address: 'Fortis Hospital, Bangalore', isAvailable: false },
  { id: '4', name: 'Dr. Priya Verma', specialty: 'Dermatologist', regNo: 'MC-44556', address: 'Medanta, Gurgaon', isAvailable: true },
];

const MOCK_REQUESTS: PatientRequest[] = [
  { id: '101', patientName: 'Amit Kumar', age: '32', symptoms: 'Fever and cough since 2 days', timestamp: '2 mins ago' },
  { id: '102', patientName: 'Sita Devi', age: '58', symptoms: 'Chest pain and shortness of breath', timestamp: '5 mins ago' },
  { id: '103', patientName: 'Rohan Joshi', age: '12', symptoms: 'Stomach ache and vomiting', timestamp: '10 mins ago' },
];

const SYSTEM_PROMPT = (lang: string) => `You are a multilingual medical scribe. The input transcript may be in English, Hindi, Hinglish (mix of English and Hindi), or Marathi. 
Regardless of the input language, you MUST extract the medical entities.
Output the final JSON in the user's selected language: ${lang}. 
However, the "Drug Name" MUST remain in English (Roman script) to ensure the pharmacist provides the correct medicine. 
All other fields (Dosage, Frequency, Duration, Instructions, Diagnosis, Warnings, FollowUp) should be written in the selected language's script (e.g., Devanagari for Hindi/Marathi).

CRITICAL MAPPING RULES:
- If the transcript contains "subah shaam" or "subah sham", always map Frequency to "BD (Twice a day)".
- If the transcript contains "khali pet", always map Instructions to include "Before Food".
- If the transcript contains "din mein teen baar", map Frequency to "TDS (Three times a day)".

If a drug name is a "look-alike/sound-alike" (LASA) medication (e.g., Lasix vs Losec), you MUST populate the "warning" field in the JSON with "High-Risk Look-alike" (in English). 
If the drug belongs to the Penicillin or Sulfa class, explicitly state the class in the warning field (in English).
Extract: {Diagnosis, Drugs: [{Name, Dosage, Frequency, Duration, Instructions, Warning}], Warnings, FollowUp}.
Output strictly in JSON format.`;

const RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    Diagnosis: { type: Type.STRING },
    Drugs: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          Name: { type: Type.STRING },
          Dosage: { type: Type.STRING },
          Frequency: { type: Type.STRING },
          Duration: { type: Type.STRING },
          Instructions: { type: Type.STRING },
          Warning: { type: Type.STRING }
        },
        required: ["Name", "Dosage", "Frequency", "Duration", "Instructions"]
      }
    },
    Warnings: {
      type: Type.ARRAY,
      items: { type: Type.STRING }
    },
    FollowUp: { type: Type.STRING }
  },
  required: ["Diagnosis", "Drugs", "Warnings", "FollowUp"]
};

const LASA_PAIRS: Record<string, string> = {
  'amlodipine': 'amiloride',
  'amiloride': 'amlodipine',
  'zantac': 'zyrtec',
  'zyrtec': 'zantac',
  'celebrex': 'celexa',
  'celexa': 'celebrex',
  'prednisone': 'prednisolone',
  'prednisolone': 'prednisone'
};

const playBeep = () => {
  try {
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // A5
    gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.5);

    oscillator.start();
    oscillator.stop(audioCtx.currentTime + 0.5);
  } catch (e) {
    console.error('Audio beep failed', e);
  }
};

export default function App() {
  // --- State ---
  const [currentState, setCurrentState] = useState<AppState>('portal');
  const [patient, setPatient] = useState<PatientInfo>({ 
    name: '', 
    age: '', 
    gender: '',
    allergies: '',
    doctorName: 'Dr. Ishaan Sharma',
    regNo: 'NMC/2026/8842',
    address: 'Apollo Hospitals, New Delhi'
  });
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeRequest, setActiveRequest] = useState<PatientRequest | null>(null);
  const [isDoctorVerified, setIsDoctorVerified] = useState(false);
  const [onboardingTarget, setOnboardingTarget] = useState<AppState>('doctor-dashboard');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationComplete, setVerificationComplete] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [prescription, setPrescription] = useState<PrescriptionData | null>(null);
  const [allergyAlerts, setAllergyAlerts] = useState<string[]>([]);
  const [activeAllergyAlert, setActiveAllergyAlert] = useState<string | null>(null);
  const [activeLasaAlert, setActiveLasaAlert] = useState<string | null>(null);
  const [isOverrideConfirmed, setIsOverrideConfirmed] = useState(false);
  const [isVibrating, setIsVibrating] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [selectedLang, setSelectedLang] = useState<Language>('hinglish');

  const recognitionRef = useRef<any>(null);
  const transcriptRef = useRef<string>('');
  const transcriptEndRef = useRef<HTMLDivElement>(null);

  const resetToGateway = () => {
    setCurrentState('portal');
    setTranscript('');
    setPrescription(null);
    setSelectedDoctor(null);
    setActiveRequest(null);
    setIsDoctorVerified(false); // Resetting active state
    setVerificationComplete(false);
    setIsVerifying(false);
  };

  // --- Global Data Controller (Auto-Render on Switch) ---
  useEffect(() => {
    if (currentState === 'patient-list') {
      console.log(`Rendering ${MOCK_DOCTORS.length} doctors...`);
      // Ensure reveal elements are active immediately for these lists
      setTimeout(() => {
        const revealElements = document.querySelectorAll('#doctors-list .reveal');
        revealElements.forEach(el => el.classList.add('active'));
      }, 100);
    } else if (currentState === 'doctor-dashboard') {
      console.log(`Rendering ${MOCK_REQUESTS.length} requests...`);
      setTimeout(() => {
        const revealElements = document.querySelectorAll('#requests-list .reveal');
        revealElements.forEach(el => el.classList.add('active'));
      }, 100);
    }
  }, [currentState]);

  // --- Intersection Observer Logic ---
  useEffect(() => {
    if (!isLoaded) return;

    const observerOptions = {
      threshold: 0.2,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
          // Once animated, we can stop observing
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);

    // We need to re-query whenever the state changes because elements are added/removed
    const revealElements = document.querySelectorAll('.reveal');
    revealElements.forEach(el => {
      // If it's already in view or we are in a state that should show it immediately
      const rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight && rect.bottom > 0) {
        el.classList.add('active');
      } else {
        observer.observe(el);
      }
    });

    return () => observer.disconnect();
  }, [isLoaded, currentState]);

  // --- Splash Screen Logic ---
  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 1500);
    return () => clearTimeout(timer);
  }, []);

  // --- Clinical Safety Monitor ---
  const checkClinicalSafety = (text: string) => {
    const lowerText = text.toLowerCase();
    
    // 1. Allergy Detection
    const patientAllergies = patient.allergies.toLowerCase().split(',').map(a => a.trim()).filter(a => a.length > 0);
    let foundAllergy = false;
    for (const allergy of patientAllergies) {
      if (lowerText.includes(allergy)) {
        if (!activeAllergyAlert) {
          playBeep();
          setIsVibrating(true);
          if (window.navigator.vibrate) {
            window.navigator.vibrate([100, 50, 100]);
          }
          setTimeout(() => setIsVibrating(false), 500);
        }
        setActiveAllergyAlert(`⚠️ ALERT: Patient is allergic to ${allergy.toUpperCase()}!`);
        foundAllergy = true;
        break;
      }
    }
    if (!foundAllergy) setActiveAllergyAlert(null);

    // 2. LASA Detection
    let foundLasa = false;
    for (const [drugA, drugB] of Object.entries(LASA_PAIRS)) {
      if (lowerText.includes(drugA)) {
        setActiveLasaAlert(`💡 Clinical Note: Did you mean ${drugB.charAt(0).toUpperCase() + drugB.slice(1)}? (Sound-alike risk)`);
        foundLasa = true;
        break;
      }
    }
    if (!foundLasa) setActiveLasaAlert(null);
  };

  // --- Speech Recognition Setup ---
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      
      // Map selection to Web Speech API lang
      const langMap: Record<Language, string> = {
        english: 'en-IN',
        hindi: 'hi-IN',
        hinglish: 'en-IN',
        marathi: 'mr-IN'
      };
      recognitionRef.current.lang = langMap[selectedLang];

      recognitionRef.current.onresult = (event: any) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        setTranscript(prev => {
          const updated = prev + final;
          transcriptRef.current = updated;
          return updated;
        });
        setInterimTranscript(interim);
        
        // Run safety check on the full current transcript
        checkClinicalSafety(transcriptRef.current + interim);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };
    }
  }, []);

  useEffect(() => {
    if (transcriptEndRef.current) {
      transcriptEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [transcript]);

  // --- Handlers ---
  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      setInterimTranscript('');
    } else {
      setTranscript('');
      transcriptRef.current = '';
      setActiveAllergyAlert(null);
      setActiveLasaAlert(null);
      setIsOverrideConfirmed(false);
      
      // Update lang right before starting to be sure
      const langMap: Record<Language, string> = {
        english: 'en-IN',
        hindi: 'hi-IN',
        hinglish: 'en-IN',
        marathi: 'mr-IN'
      };
      if (recognitionRef.current) {
        recognitionRef.current.lang = langMap[selectedLang];
      }
      
      recognitionRef.current?.start();
      setIsListening(true);
    }
  };

  const handleStopRecording = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      setInterimTranscript('');
    }
    setCurrentState('review-transcript');
  };

  const generatePrescription = async () => {
    setCurrentState('processing');
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: transcript,
        config: {
          systemInstruction: SYSTEM_PROMPT(selectedLang),
          responseMimeType: "application/json",
          responseSchema: RESPONSE_SCHEMA
        }
      });

      const data = JSON.parse(response.text || '{}') as PrescriptionData;
      
      // Safety Filter Logic
      const alerts: string[] = [];
      const pAllergies = patient.allergies.toLowerCase();
      
      data.Drugs.forEach(drug => {
        const drugName = drug.Name.toLowerCase();
        
        // Specific Penicillin Rule
        if (pAllergies.includes('penicillin') && (drugName.includes('amox') || drugName.includes('pen'))) {
          drug.Warning = "ALLERGY ALERT: PENICILLIN CLASS DETECTED";
          alerts.push(`CRITICAL: Patient is allergic to Penicillin. Detected in ${drug.Name}.`);
        }
        
        // General Allergy Check
        const allergyList = pAllergies.split(',').map(a => a.trim());
        allergyList.forEach(allergy => {
          if (allergy && drugName.includes(allergy) && !drug.Warning) {
            drug.Warning = `ALLERGY ALERT: ${allergy.toUpperCase()}`;
            alerts.push(`ALLERGY ALERT: Patient is allergic to ${allergy}. Detected in ${drug.Name}.`);
          }
        });
      });

      setPrescription(data);
      setAllergyAlerts(alerts);
      setCurrentState('review');
    } catch (error) {
      console.error('Error processing medical voice:', error);
      setCurrentState('recording');
    }
  };

  const handleRecordAgain = () => {
    setTranscript('');
    setPrescription(null);
    setAllergyAlerts([]);
    setCurrentState('recording');
  };

  const handleApprove = () => {
    showFinalPrescription();
  };

  const showFinalPrescription = () => {
    // Collect text from editable fields if needed, but they are already in state
    setCurrentState('final');
  };

  const handlePrint = () => {
    window.print();
  };

  const t = translations[selectedLang];
  const langFlags: Record<Language, string> = {
    english: '🇬🇧',
    hindi: '🇮🇳',
    hinglish: '🇮🇳',
    marathi: '🇮🇳'
  };

  // --- UI Components ---
  return (
    <div className={`min-h-screen font-manrope text-white selection:bg-primary-blue/30 overflow-x-hidden transition-colors duration-700 ${currentState === 'final' ? 'bg-white !text-black' : ''} ${isVibrating ? 'vibrate' : ''}`}>
      {/* Background Blobs */}
      <div className="bg-blobs no-print">
        <div className="blob-1" />
        <div className="blob-2" />
      </div>

      {/* Splash Screen */}
      <AnimatePresence>
        {!isLoaded && (
          <motion.div 
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9999] bg-navy flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0.8, filter: 'blur(10px)', opacity: 0 }}
              animate={{ scale: 1, filter: 'blur(0px)', opacity: 1 }}
              transition={{ duration: 1, ease: [0.23, 1, 0.32, 1] }}
              className="flex items-center gap-4"
            >
              <div className="w-16 h-16 bg-primary-blue rounded-2xl flex items-center justify-center shadow-2xl shadow-primary-blue/20">
                <Stethoscope size={32} className="text-white" />
              </div>
              <h1 className="text-4xl font-bold font-rx tracking-tight">Speak Prescript</h1>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <header className={`p-6 flex justify-between items-center no-print transition-all relative z-[1000] ${currentState === 'final' ? 'border-b border-gray-100' : ''}`}>
        <motion.div 
          initial={false}
          animate={isLoaded ? { x: 0, opacity: 1 } : { x: 20, opacity: 0 }}
          className="flex items-center gap-3 cursor-pointer"
          onClick={resetToGateway}
        >
          {currentState !== 'portal' && (
            <button 
              onClick={(e) => {
                e.stopPropagation();
                resetToGateway();
              }}
              className="p-2 hover:bg-white/10 rounded-full transition-all mr-2"
              title={t.backToHome}
            >
              <Home size={20} className={currentState === 'final' ? 'text-black' : 'text-white'} />
            </button>
          )}
          <div className="w-10 h-10 bg-primary-blue rounded-xl flex items-center justify-center shadow-lg shadow-primary-blue/20 relative">
            <Stethoscope size={20} className="text-white" />
            <Activity size={12} className="absolute bottom-1 right-1 text-success-green" />
          </div>
          <h1 className={`text-xl font-bold tracking-tight font-rx transition-colors ${currentState === 'final' ? 'text-black' : 'text-white'}`}>Speak Prescript</h1>
        </motion.div>
        <div className="flex items-center gap-4 no-print">
          <div className="lang-toggle !mb-0">
            {(['english', 'hindi', 'hinglish', 'marathi'] as Language[]).map(lang => (
              <button
                key={lang}
                onClick={() => !isListening && setSelectedLang(lang)}
                disabled={isListening}
                className={`lang-option ${selectedLang === lang ? 'active' : ''}`}
              >
                {lang}
              </button>
            ))}
          </div>
          {currentState === 'final' && (
            <button 
              onClick={handlePrint}
              className="flex items-center gap-2 bg-primary-blue text-white px-6 py-2 rounded-lg transition-all shadow-lg shadow-primary-blue/20 hover:scale-105 active:scale-95 btn-glow"
            >
              <Printer size={18} />
              <span>{t.printPrescription}</span>
            </button>
          )}
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 pb-24 relative z-[50]">
        <AnimatePresence mode="wait">
          {/* State: Portal */}
          {currentState === 'portal' && (
            <motion.div 
              key="portal"
              id="role-gateway"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid md:grid-cols-3 gap-8 py-20 opacity-100 visible flex app-section relative z-[999]"
            >
              <button 
                onClick={() => setCurrentState('patient-list')}
                className="glass-card p-10 text-left hover:scale-105 transition-all group reveal active bobbing"
              >
                <div className="w-16 h-16 bg-success-green/20 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-success-green/30 transition-colors">
                  <User size={32} className="text-success-green" />
                </div>
                <h3 className="text-2xl font-bold mb-4">{t.iAmPatient}</h3>
                <p className="text-white/40 leading-relaxed">{t.findDoctor}</p>
                <div className="mt-8 flex items-center gap-2 text-success-green font-bold">
                  <span>{t.startConsultation}</span>
                  <ArrowRight size={18} className="group-hover:translate-x-2 transition-transform" />
                </div>
              </button>

              <button 
                onClick={() => {
                  if (isDoctorVerified) {
                    setCurrentState('doctor-dashboard');
                  } else {
                    setOnboardingTarget('doctor-dashboard');
                    setCurrentState('doctor-onboarding');
                  }
                }}
                className="glass-card p-10 text-left hover:scale-105 transition-all group reveal active bobbing"
                style={{ animationDelay: '0.2s' }}
              >
                <div className="w-16 h-16 bg-primary-blue/20 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-primary-blue/30 transition-colors">
                  <Video size={32} className="text-primary-blue" />
                </div>
                <h3 className="text-2xl font-bold mb-4">{t.iAmDoctorLive}</h3>
                <p className="text-white/40 leading-relaxed">{t.seeRequests}</p>
                <div className="mt-8 flex items-center gap-2 text-primary-blue font-bold">
                  <span>{t.liveConsultation}</span>
                  <ArrowRight size={18} className="group-hover:translate-x-2 transition-transform" />
                </div>
              </button>

              <button 
                onClick={() => {
                  if (isDoctorVerified) {
                    setCurrentState('registration');
                  } else {
                    setOnboardingTarget('registration');
                    setCurrentState('doctor-onboarding');
                  }
                }}
                className="glass-card p-10 text-left hover:scale-105 transition-all group reveal active bobbing"
                style={{ animationDelay: '0.4s' }}
              >
                <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-white/20 transition-colors">
                  <Mic size={32} className="text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-4">{t.iAmDoctorScribe}</h3>
                <p className="text-white/40 leading-relaxed">{t.voiceTool}</p>
                <div className="mt-8 flex items-center gap-2 text-white font-bold">
                  <span>{t.miniScribe}</span>
                  <ArrowRight size={18} className="group-hover:translate-x-2 transition-transform" />
                </div>
              </button>
            </motion.div>
          )}

          {/* State: Doctor Onboarding */}
          {currentState === 'doctor-onboarding' && (
            <motion.div 
              key="doctor-onboarding"
              id="onboarding-section"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="py-12 max-w-2xl mx-auto flex flex-col items-center relative z-[100] app-section"
            >
              {/* Branded Character: Stethoscope with a Cape */}
              <motion.div 
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="mb-8 relative"
              >
                <div className="w-24 h-24 bg-primary-blue rounded-3xl flex items-center justify-center shadow-2xl shadow-primary-blue/40 relative z-10">
                  <Stethoscope size={48} className="text-white" />
                </div>
                {/* Cape Effect */}
                <motion.div 
                  animate={{ 
                    rotate: [-5, 5, -5],
                    scaleX: [1, 1.1, 1]
                  }}
                  transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                  className="absolute -bottom-2 -left-4 -right-4 h-12 bg-primary-blue/30 blur-xl rounded-full -z-10"
                />
                <div className="absolute -top-4 -right-4 w-12 h-12 bg-success-green rounded-full flex items-center justify-center shadow-lg border-4 border-navy">
                  <Plus size={20} className="text-white" />
                </div>
              </motion.div>

              <div className="text-center space-y-4 mb-12">
                <h2 className="text-5xl font-bold tracking-tight">{t.doctorOnboarding}</h2>
                <p className="text-white/40 text-lg">{t.onboardingDesc}</p>
              </div>

              <div className="glass-card p-12 space-y-10 w-full reveal active">
                {!verificationComplete ? (
                  <>
                    <div className="space-y-8">
                      <div className="floating-input-group">
                        <input 
                          type="text" 
                          placeholder=" "
                          className="floating-input"
                          defaultValue="Dr. Ishaan Sharma"
                        />
                        <label className="floating-label">{t.fullNameSpec}</label>
                        <div className="input-focus-line" />
                      </div>
                      <div className="floating-input-group">
                        <input 
                          type="text" 
                          placeholder=" "
                          className="floating-input"
                          defaultValue="NMC-98765-DL"
                        />
                        <label className="floating-label">{t.medRegNo}</label>
                        <div className="input-focus-line" />
                      </div>
                    </div>

                    <button 
                      id="verify-doc-btn"
                      onClick={() => {
                        setIsVerifying(true);
                        setTimeout(() => {
                          setIsVerifying(false);
                          setVerificationComplete(true);
                          setIsDoctorVerified(true);
                        }, 1500);
                      }}
                      disabled={isVerifying}
                      className="primary-btn"
                    >
                      {isVerifying ? (
                        <>
                          <motion.div 
                            animate={{ rotate: 360 }}
                            transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                            className="w-6 h-6 border-2 border-white/20 border-t-white rounded-full"
                          />
                          <span>Verifying with National Medical Register...</span>
                        </>
                      ) : (
                        <>
                          <CheckCircle2 size={24} />
                          <span>Verify Identity & Enter Dashboard</span>
                        </>
                      )}
                    </button>
                  </>
                ) : (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex flex-col items-center justify-center py-10 space-y-8"
                  >
                    <div className="w-24 h-24 bg-success-green/20 rounded-full flex items-center justify-center">
                      <CheckCircle2 size={48} className="text-success-green" />
                    </div>
                    <div className="text-center space-y-2">
                      <h3 className="text-3xl font-bold text-success-green">{t.verified}</h3>
                      <p className="text-white/40">NMC Credentials Authenticated via HPR</p>
                    </div>
                    <button 
                      onClick={() => {
                        setCurrentState(onboardingTarget);
                        setVerificationComplete(false);
                      }}
                      className="px-12 py-5 rounded-2xl bg-white text-navy font-bold transition-all hover:scale-105 active:scale-95 shadow-2xl text-lg relative z-[130]"
                    >
                      {t.enterDashboard}
                    </button>
                  </motion.div>
                )}
              </div>
            </motion.div>
          )}

          {/* State: Patient List */}
          {currentState === 'patient-list' && (
            <motion.div 
              key="patient-list"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="py-12 space-y-12 app-section"
            >
              <div className="flex flex-col md:flex-row justify-between items-end gap-6">
                <div className="space-y-4">
                  <h2 className="text-5xl font-bold tracking-tight">{t.availableDoctors}</h2>
                  <p className="text-white/40 text-lg">{t.findDoctor}</p>
                </div>
                <div className="relative w-full md:w-96">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" size={20} />
                  <input 
                    type="text" 
                    placeholder={t.searchDoctor}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-6 outline-none focus:border-primary-blue transition-all"
                  />
                </div>
              </div>

              <div id="doctors-list" className="grid md:grid-cols-2 gap-6 opacity-100 visible flex">
                {MOCK_DOCTORS.filter(d => d.name.toLowerCase().includes(searchQuery.toLowerCase()) || d.specialty.toLowerCase().includes(searchQuery.toLowerCase())).map(doc => (
                  <div key={doc.id} className="glass-card p-8 flex flex-col justify-between hover:border-white/20 transition-all reveal active">
                    <div className="space-y-4">
                      <div className="flex justify-between items-start">
                        <div className="w-12 h-12 bg-primary-blue/10 rounded-xl flex items-center justify-center">
                          <Stethoscope size={24} className="text-primary-blue" />
                        </div>
                        <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${doc.isAvailable ? 'bg-success-green/10 text-success-green' : 'bg-white/5 text-white/30'}`}>
                          {doc.isAvailable ? 'Online' : 'Offline'}
                        </div>
                      </div>
                      <div>
                        <h4 className="text-xl font-bold">{doc.name}</h4>
                        <p className="text-primary-blue font-medium">{doc.specialty}</p>
                      </div>
                      <p className="text-white/40 text-sm">{doc.address}</p>
                    </div>
                    <button 
                      onClick={() => {
                        setSelectedDoctor(doc);
                        setCurrentState('patient-waiting');
                      }}
                      disabled={!doc.isAvailable}
                      className="mt-8 w-full py-4 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-all font-bold flex items-center justify-center gap-2"
                    >
                      <Video size={18} />
                      <span>{t.requestVideoCall}</span>
                    </button>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* State: Patient Waiting */}
          {currentState === 'patient-waiting' && (
            <motion.div 
              key="patient-waiting"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center min-h-[60vh] space-y-12 app-section"
            >
              <div className="relative">
                <div className="w-48 h-48 rounded-full border-4 border-primary-blue/20 flex items-center justify-center">
                  <motion.div 
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className="w-40 h-40 rounded-full bg-primary-blue/10 flex items-center justify-center"
                  >
                    <Video size={64} className="text-primary-blue" />
                  </motion.div>
                </div>
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
                  className="absolute inset-0 border-t-4 border-primary-blue rounded-full"
                />
              </div>
              <div className="text-center space-y-4">
                <h2 className="text-4xl font-bold tracking-tight animate-pulse">{t.waitingForDoctor}</h2>
                <p className="text-white/40 text-lg">{selectedDoctor?.name} is reviewing your request...</p>
              </div>
              <button 
                onClick={() => setCurrentState('patient-list')}
                className="px-10 py-4 rounded-2xl bg-white/5 hover:bg-white/10 transition-all font-bold"
              >
                Cancel Request
              </button>
            </motion.div>
          )}

          {/* State: Doctor Dashboard */}
          {currentState === 'doctor-dashboard' && (
            <motion.div 
              key="doctor-dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="py-12 space-y-12 app-section"
            >
              <div className="space-y-4">
                <h2 className="text-5xl font-bold tracking-tight">{t.incomingRequests}</h2>
                <p className="text-white/40 text-lg">Manage your live consultation queue.</p>
              </div>

              <div id="requests-list" className="space-y-6 opacity-100 visible flex flex-col">
                {MOCK_REQUESTS.map(req => (
                  <div key={req.id} className="glass-card p-8 flex flex-col md:flex-row justify-between items-center gap-8 reveal active">
                    <div className="flex items-center gap-6 w-full">
                      <div className="w-16 h-16 bg-success-green/10 rounded-2xl flex items-center justify-center shrink-0">
                        <User size={32} className="text-success-green" />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-3">
                          <h4 className="text-2xl font-bold">{req.patientName}</h4>
                          <span className="text-white/30 text-sm">{req.age}Y</span>
                        </div>
                        <p className="text-white/60 italic">"{req.symptoms}"</p>
                        <p className="text-white/20 text-xs font-bold uppercase tracking-widest">{req.timestamp}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => {
                        setActiveRequest(req);
                        setPatient({
                          name: req.patientName,
                          age: req.age,
                          gender: 'Unknown',
                          allergies: 'None reported',
                          doctorName: 'Dr. Ishaan Sharma',
                          regNo: 'MC-12345',
                          address: 'Apollo Hospitals, New Delhi'
                        });
                        setCurrentState('live-consultation');
                      }}
                      className="w-full md:w-auto px-10 py-5 rounded-2xl bg-primary-blue hover:bg-primary-blue/90 text-white font-bold transition-all flex items-center justify-center gap-3 shadow-xl shadow-primary-blue/20 btn-glow"
                    >
                      <Phone size={20} />
                      <span>{t.acceptAndCall}</span>
                    </button>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* State: Live Consultation */}
          {currentState === 'live-consultation' && (
            <motion.div 
              key="live-consultation"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-navy flex flex-col app-section"
            >
              {/* Video Feed (70%) */}
              <div className="flex-grow relative bg-black/40 overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center space-y-6 opacity-40">
                    <div className="w-32 h-32 bg-white/5 rounded-full flex items-center justify-center mx-auto">
                      <User size={64} />
                    </div>
                    <h2 className="text-3xl font-bold">{activeRequest?.patientName}</h2>
                    <div className="flex items-center justify-center gap-3">
                      <div className="w-3 h-3 bg-success-green rounded-full animate-pulse" />
                      <span className="text-sm font-bold uppercase tracking-widest">Live Connection</span>
                    </div>
                  </div>
                </div>

                {/* Self View */}
                <div className="absolute top-8 right-8 w-48 h-64 bg-white/5 rounded-3xl border border-white/10 overflow-hidden shadow-2xl">
                  <div className="absolute inset-0 flex items-center justify-center opacity-20">
                    <Stethoscope size={48} />
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">You (Doctor)</p>
                  </div>
                </div>

                {/* Controls */}
                <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-6">
                  <button className="w-14 h-14 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all">
                    <MicOff size={24} />
                  </button>
                  <button 
                    onClick={() => setCurrentState('portal')}
                    className="w-20 h-20 rounded-full bg-red-500 hover:bg-red-600 flex items-center justify-center transition-all shadow-2xl shadow-red-500/20"
                  >
                    <X size={32} />
                  </button>
                  <button className="w-14 h-14 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all">
                    <Video size={24} />
                  </button>
                </div>
              </div>

              {/* Mini Scribe (30%) */}
              <div className="h-[35vh] bg-white/5 backdrop-blur-3xl border-t border-white/10 p-8 flex flex-col">
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-primary-blue rounded-lg flex items-center justify-center">
                      <ClipboardList size={16} />
                    </div>
                    <h3 className="text-sm font-bold uppercase tracking-[0.2em] text-primary-blue">{t.miniScribe}</h3>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="lang-toggle !mb-0 !scale-75">
                      {(['english', 'hindi', 'hinglish', 'marathi'] as Language[]).map(lang => (
                        <button
                          key={lang}
                          onClick={() => !isListening && setSelectedLang(lang)}
                          disabled={isListening}
                          className={`lang-option ${selectedLang === lang ? 'active' : ''}`}
                        >
                          {lang}
                        </button>
                      ))}
                    </div>
                    {transcript && (
                      <button 
                        onClick={handleStopRecording}
                        className="px-6 py-2 rounded-xl bg-success-green text-navy font-bold text-sm transition-all btn-glow"
                      >
                        {t.stopAndPreview}
                      </button>
                    )}
                  </div>
                </div>

                <div className="flex-grow flex gap-8">
                  <div className="w-1/4 flex flex-col items-center justify-center border-r border-white/10">
                    <button 
                      onClick={toggleListening}
                      className={`w-24 h-24 rounded-full flex items-center justify-center transition-all ${isListening ? 'bg-red-500 animate-pulse' : 'bg-primary-blue hover:bg-primary-blue/90'}`}
                    >
                      {isListening ? <MicOff size={32} /> : <Mic size={32} />}
                    </button>
                    <p className="mt-4 text-[10px] font-bold uppercase tracking-widest text-white/40">
                      {isListening ? t.listening : t.tapToStart}
                    </p>
                  </div>
                  <div className="flex-grow overflow-y-auto custom-scrollbar p-4">
                    {transcript || interimTranscript ? (
                      <p className="text-xl leading-relaxed text-white/80 italic">
                        {transcript}
                        {interimTranscript && (
                          <span className="text-white/40"> {interimTranscript}</span>
                        )}
                        <span className="animate-pulse inline-block w-1 h-6 bg-primary-blue ml-1 align-middle" />
                      </p>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full opacity-20">
                        <Activity size={32} />
                        <p className="text-sm mt-2">{t.waitingForVoice}</p>
                      </div>
                    )}
                    <div ref={transcriptEndRef} />
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* State: Registration */}
          {currentState === 'registration' && (
            <motion.div 
              key="registration"
              id="scribe-section"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="py-12 app-section relative z-[100] w-full max-w-5xl mx-auto"
            >
              <div className="grid md:grid-cols-12 gap-8">
                {/* Left Column: Doctor Info (Read Only) */}
                <div className="md:col-span-4 space-y-6">
                  <div className="glass-card p-8 border-l-4 border-primary-blue">
                    <div className="flex items-center justify-between mb-6">
                      <span className="text-xs font-bold uppercase tracking-widest text-white/40">{t.doctorOnDuty}</span>
                      <div className="flex items-center gap-1 bg-success-green/20 text-success-green px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-tighter">
                        <CheckCircle2 size={12} />
                        <span>Verified</span>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-primary-blue/10 rounded-xl flex items-center justify-center">
                          <Stethoscope size={24} className="text-primary-blue" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-white">{patient.doctorName}</h4>
                          <p className="text-sm text-white font-bold">{patient.regNo}</p>
                        </div>
                      </div>
                      
                      <div className="pt-4 border-t border-white/5">
                        <p className="text-xs text-white/30 leading-relaxed">
                          {patient.address}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="p-6 bg-white/5 rounded-3xl border border-white/10">
                    <h5 className="text-xs font-bold uppercase tracking-widest text-primary-blue mb-3">Session Security</h5>
                    <p className="text-xs text-white/40 leading-relaxed">
                      This clinical session is encrypted. All voice data is processed locally for HIPAA compliance.
                    </p>
                  </div>
                </div>

                {/* Right Column: Patient Intake (Editable) */}
                <div className="md:col-span-8">
                  <div className="glass-card p-10 space-y-10">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-success-green/20 rounded-xl flex items-center justify-center">
                        <User size={20} className="text-success-green" />
                      </div>
                      <h3 className="text-2xl font-bold text-white">{t.patientDetails}</h3>
                    </div>

                    <div className="grid gap-8">
                      <div className="space-y-2">
                        <label style={{ color: 'white', fontWeight: 600, display: 'block', marginBottom: '5px' }}>Patient Name</label>
                        <div className="floating-input-group !pt-0">
                          <input 
                            type="text" 
                            value={patient.name}
                            onChange={e => setPatient({...patient, name: e.target.value})}
                            placeholder="Enter Patient Name"
                            className="floating-input"
                            id="pName"
                          />
                          <div className="input-focus-line" />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-8">
                        <div className="space-y-2">
                          <label style={{ color: 'white', fontWeight: 600, display: 'block', marginBottom: '5px' }}>{t.age}</label>
                          <div className="floating-input-group !pt-0">
                            <input 
                              type="number" 
                              value={patient.age}
                              onChange={e => setPatient({...patient, age: e.target.value})}
                              placeholder="Age"
                              className="floating-input"
                              id="pAge"
                            />
                            <div className="input-focus-line" />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label style={{ color: 'white', fontWeight: 600, display: 'block', marginBottom: '5px' }}>{t.gender}</label>
                          <div className="floating-input-group !pt-0">
                            <select 
                              value={patient.gender}
                              onChange={e => setPatient({...patient, gender: e.target.value})}
                              className="floating-input appearance-none bg-transparent"
                              id="pGender"
                            >
                              <option value="" disabled hidden>Select Gender</option>
                              <option value="Male" className="bg-navy">Male</option>
                              <option value="Female" className="bg-navy">Female</option>
                              <option value="Other" className="bg-navy">Other</option>
                            </select>
                            <div className="input-focus-line" />
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label style={{ color: 'white', fontWeight: 600, display: 'block', marginBottom: '5px' }}>Known Allergies / Medical History</label>
                        <div className="floating-input-group !pt-0">
                          <textarea 
                            value={patient.allergies}
                            onChange={e => setPatient({...patient, allergies: e.target.value})}
                            placeholder="Enter Known Allergies or Existing Conditions"
                            className="floating-input h-32 resize-none"
                            id="pAllergies"
                            rows={3}
                          />
                          <div className="input-focus-line" />
                        </div>
                      </div>
                    </div>

                    <button 
                      onClick={() => setCurrentState('recording')}
                      disabled={!patient.name || !patient.age || !patient.gender}
                      className="w-full py-6 rounded-2xl bg-primary-blue hover:bg-primary-blue/90 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold transition-all flex items-center justify-center gap-4 shadow-2xl shadow-primary-blue/20 text-xl btn-glow mt-4"
                    >
                      <Mic size={24} />
                      <span>{t.proceedToVoice}</span>
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* State: Recording */}
          {currentState === 'recording' && (
            <motion.div 
              key="recording"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              id="scribe-intake"
              className="flex flex-col items-center justify-center min-h-[70vh] space-y-12 pb-40 app-section"
            >
              <div className="text-center space-y-6">
                <div className="flex items-center justify-center gap-3 text-primary-blue bg-primary-blue/10 px-6 py-2 rounded-full w-fit mx-auto">
                  <User size={18} />
                  <span className="font-bold uppercase tracking-widest text-xs">{patient.name}, {patient.age}{selectedLang === 'english' || selectedLang === 'hinglish' ? 'Y' : ''}</span>
                </div>
                <h2 className="text-5xl font-bold tracking-tight">{t.acousticLayer}</h2>
                <p className="text-white/40 text-lg max-w-md mx-auto">{t.speakClearly}</p>
              </div>

              {/* Clinical Safety Alerts */}
              <div id="live-safety-alert" className="fixed top-24 left-1/2 -translate-x-1/2 z-[9999] w-full max-w-xl space-y-4 px-4">
                <AnimatePresence>
                  {activeAllergyAlert && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9, y: -20 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: -20 }}
                      className="flashing-alert p-6 rounded-2xl border-2 border-red-500 text-white text-center shadow-[0_0_30px_rgba(239,68,68,0.6)]"
                    >
                      <div className="flex items-center justify-center gap-3">
                        <AlertTriangle size={32} className="animate-bounce" />
                        <span className="text-2xl font-black uppercase tracking-tighter">{activeAllergyAlert}</span>
                      </div>
                    </motion.div>
                  )}
                  {activeLasaAlert && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9, y: -20 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: -20 }}
                      className="bg-yellow-500/90 backdrop-blur-md p-4 rounded-xl border border-yellow-400 text-navy text-center shadow-xl"
                    >
                      <div className="flex items-center justify-center gap-2">
                        <Info size={20} />
                        <span className="text-sm font-bold">{activeLasaAlert}</span>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div id="dictation-section" className="no-print">
                <button 
                  onClick={toggleListening}
                  className={`mic-button ${activeAllergyAlert ? 'is-alert' : isListening ? 'is-recording' : ''}`}
                >
                  {isListening ? <MicOff size={32} /> : <Mic size={32} />}
                </button>
                <p className="mic-label">
                  {isListening ? (
                    <span className="flex items-center gap-2">
                      {langFlags[selectedLang]}
                      {t.listening}
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <span className="opacity-50">{langFlags[selectedLang]}</span>
                      {t.tapToStart}
                    </span>
                  )}
                </p>
              </div>

              <div className="w-full max-w-3xl glass-card p-10 h-64 overflow-y-auto custom-scrollbar reveal">
                {transcript || interimTranscript ? (
                  <p className="text-2xl leading-relaxed text-white/80 italic font-medium">
                    {transcript}
                    {interimTranscript && (
                      <span className="text-white/40"> {interimTranscript}</span>
                    )}
                    <span className="animate-pulse inline-block w-1 h-8 bg-primary-blue ml-1 align-middle" />
                  </p>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full space-y-4 opacity-20">
                    <Activity size={48} />
                    <p className="text-xl">{t.waitingForVoice}</p>
                  </div>
                )}
                <div ref={transcriptEndRef} />
              </div>

              {/* Live Transcript Window */}
              <AnimatePresence>
                {isListening && interimTranscript && (
                  <motion.div 
                    id="live-transcript"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="w-full max-w-2xl bg-white/5 backdrop-blur-md border border-white/10 p-6 rounded-2xl text-center"
                  >
                    <p className="text-lg text-white font-medium italic">
                      {interimTranscript}
                      <span className="inline-block w-2 h-2 bg-primary-blue rounded-full ml-2 animate-ping" />
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="flex gap-6">
                <button 
                  onClick={() => setCurrentState('registration')}
                  className="px-10 py-4 rounded-2xl bg-white/5 hover:bg-white/10 transition-all font-bold text-lg"
                >
                  {t.back}
                </button>
                {transcript && (
                  <button 
                    onClick={handleStopRecording}
                    className="px-14 py-4 rounded-2xl bg-success-green hover:bg-success-green/90 text-navy font-bold transition-all flex items-center gap-3 shadow-2xl shadow-success-green/20 text-lg btn-glow"
                  >
                    <CheckCircle2 size={24} />
                    <span>{t.stopAndPreview}</span>
                  </button>
                )}
              </div>
            </motion.div>
          )}

          {/* State: Review Transcript */}
          {currentState === 'review-transcript' && (
            <motion.div 
              key="review-transcript"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col items-center justify-center min-h-[70vh] space-y-10 app-section w-full max-w-4xl mx-auto"
            >
              <div className="text-center space-y-4">
                <h2 className="text-4xl font-bold tracking-tight">Review Transcript</h2>
                <p className="text-white/40">Edit the captured text before generating the final prescription.</p>
              </div>

              <div className="w-full glass-card p-8 space-y-6">
                <textarea 
                  value={transcript}
                  onChange={(e) => {
                    setTranscript(e.target.value);
                    checkClinicalSafety(e.target.value);
                  }}
                  className="w-full h-64 bg-white/5 border border-white/10 rounded-2xl p-6 text-xl text-white outline-none focus:border-primary-blue transition-all custom-scrollbar"
                  placeholder="Captured transcript will appear here..."
                />

                {activeAllergyAlert && (
                  <div className="p-6 bg-red-500/10 border border-red-500/30 rounded-2xl flex items-center justify-between gap-6">
                    <div className="flex items-center gap-4 text-red-500">
                      <AlertTriangle size={24} />
                      <p className="font-bold">{activeAllergyAlert}</p>
                    </div>
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <input 
                        type="checkbox" 
                        checked={isOverrideConfirmed}
                        onChange={(e) => setIsOverrideConfirmed(e.target.checked)}
                        className="w-6 h-6 rounded border-red-500 text-red-500 focus:ring-red-500 bg-transparent"
                      />
                      <span className="text-sm font-bold text-white/60 group-hover:text-white transition-colors">Confirm Clinical Override</span>
                    </label>
                  </div>
                )}

                <div className="flex gap-6">
                  <button 
                    onClick={() => setCurrentState('recording')}
                    className="flex-1 py-5 rounded-2xl bg-white/5 hover:bg-white/10 transition-all font-bold text-lg"
                  >
                    Record Again
                  </button>
                  <button 
                    onClick={generatePrescription}
                    disabled={activeAllergyAlert !== null && !isOverrideConfirmed}
                    className={`flex-[2] py-5 rounded-2xl font-bold transition-all flex items-center justify-center gap-3 shadow-2xl text-xl btn-glow ${
                      activeAllergyAlert 
                        ? 'bg-red-500 hover:bg-red-600 shadow-red-500/20' 
                        : 'bg-primary-blue hover:bg-primary-blue/90 shadow-primary-blue/20'
                    } disabled:opacity-50 disabled:cursor-not-allowed`}
                  >
                    <span>✨ Refine & Generate Prescription</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* State: Processing */}
          {currentState === 'processing' && (
            <motion.div 
              key="processing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center min-h-[70vh] space-y-10 app-section"
            >
              <div className="relative w-32 h-32">
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                  className="absolute inset-0 border-4 border-primary-blue/10 border-t-primary-blue rounded-full"
                />
                <motion.div 
                  animate={{ rotate: -360 }}
                  transition={{ repeat: Infinity, duration: 3, ease: "linear" }}
                  className="absolute inset-4 border-4 border-success-green/10 border-t-success-green rounded-full"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Activity size={32} className="text-primary-blue animate-pulse" />
                </div>
              </div>
              <div className="text-center space-y-4">
                <h3 className="text-3xl font-bold text-white">Refining Prescription...</h3>
                <p className="text-white/40 max-w-xs mx-auto">AI is structuring your consultation into a clinical document.</p>
              </div>
            </motion.div>
          )}

          {/* State: Review */}
          {currentState === 'review' && prescription && (
            <motion.div 
              key="review"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              id="review-stage"
              className="py-12 space-y-12 app-section"
            >
              <div className="text-center space-y-3">
                <h2 className="text-4xl font-bold tracking-tight">{t.reviewData}</h2>
                <p className="text-white/40 text-lg">{t.verifyEdit}</p>
              </div>

              {/* Safety Layer Alerts */}
              {allergyAlerts.length > 0 && (
                <motion.div 
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  className="bg-red-500/10 border border-red-500/20 p-6 rounded-3xl flex gap-4 items-start backdrop-blur-md"
                >
                  <AlertCircle className="text-red-500 shrink-0" size={28} />
                  <div className="space-y-2">
                    <h4 className="font-bold text-red-500 text-lg">{t.safetyWarning}</h4>
                    {allergyAlerts.map((alert, i) => (
                      <p key={i} className="text-red-400 font-medium">{alert}</p>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Editable Card */}
              <div id="editable-transcript" className="glass-card p-12 reveal">
                <div className="grid md:grid-cols-3 gap-16">
                  <div className="md:col-span-2 space-y-12">
                    <section className="group">
                      <span className="text-xs font-bold uppercase tracking-[0.2em] text-primary-blue block mb-4">{t.diagnosis}</span>
                      <div 
                        contentEditable 
                        suppressContentEditableWarning
                        onBlur={(e) => setPrescription({...prescription, Diagnosis: e.currentTarget.textContent || ''})}
                        className="text-3xl font-bold outline-none focus:bg-white/5 p-4 -m-4 rounded-2xl transition-all border border-transparent focus:border-white/10"
                      >
                        {prescription.Diagnosis}
                      </div>
                    </section>

                    <section className="space-y-8">
                      <span className="text-xs font-bold uppercase tracking-[0.2em] text-success-green block mb-4">{t.medicationPlan}</span>
                      <div className="space-y-6">
                        {prescription.Drugs.map((drug, idx) => (
                          <div key={idx} className={`drug-item p-8 rounded-[24px] border transition-all duration-500 ${drug.Warning ? 'warning' : 'bg-white/5 border-white/10 hover:bg-white/10'}`}>
                            <div className="flex justify-between items-start mb-6">
                              <div className="space-y-2">
                                <h4 
                                  contentEditable 
                                  suppressContentEditableWarning
                                  onBlur={(e) => {
                                    const newDrugs = [...prescription.Drugs];
                                    newDrugs[idx].Name = e.currentTarget.textContent || '';
                                    setPrescription({...prescription, Drugs: newDrugs});
                                  }}
                                  className="text-2xl font-bold outline-none"
                                >
                                  {drug.Name}
                                </h4>
                                {drug.Warning && (
                                  <span className="warning-text flex items-center gap-2 mt-2">
                                    <AlertCircle size={16} />
                                    {drug.Warning}
                                  </span>
                                )}
                              </div>
                              <span className="text-xs font-bold bg-white/10 px-3 py-1.5 rounded-full uppercase tracking-widest">{drug.Duration}</span>
                            </div>
                            <div className="flex gap-6 text-white/40 text-sm font-bold uppercase tracking-widest mb-6">
                              <span 
                                contentEditable 
                                suppressContentEditableWarning
                                onBlur={(e) => {
                                  const newDrugs = [...prescription.Drugs];
                                  newDrugs[idx].Dosage = e.currentTarget.textContent || '';
                                  setPrescription({...prescription, Drugs: newDrugs});
                                }}
                                className="outline-none focus:text-white"
                              >
                                {drug.Dosage}
                              </span>
                              <span className="opacity-20">•</span>
                              <span 
                                contentEditable 
                                suppressContentEditableWarning
                                onBlur={(e) => {
                                  const newDrugs = [...prescription.Drugs];
                                  newDrugs[idx].Frequency = e.currentTarget.textContent || '';
                                  setPrescription({...prescription, Drugs: newDrugs});
                                }}
                                className="outline-none focus:text-white"
                              >
                                {drug.Frequency}
                              </span>
                            </div>
                            <p 
                              contentEditable 
                              suppressContentEditableWarning
                              onBlur={(e) => {
                                const newDrugs = [...prescription.Drugs];
                                newDrugs[idx].Instructions = e.currentTarget.textContent || '';
                                setPrescription({...prescription, Drugs: newDrugs});
                              }}
                              className="text-white/60 text-lg italic outline-none leading-relaxed"
                            >
                              {drug.Instructions}
                            </p>
                          </div>
                        ))}
                      </div>
                    </section>
                  </div>

                  <div className="space-y-16">
                    <section>
                      <span className="text-xs font-bold uppercase tracking-[0.2em] text-white/40 block mb-6">{t.warnings}</span>
                      <ul className="space-y-4">
                        {prescription.Warnings.map((warning, i) => (
                          <li 
                            key={i} 
                            contentEditable 
                            suppressContentEditableWarning
                            onBlur={(e) => {
                              const newWarnings = [...prescription.Warnings];
                              newWarnings[i] = e.currentTarget.textContent || '';
                              setPrescription({...prescription, Warnings: newWarnings});
                            }}
                            className="text-lg text-white/70 outline-none p-3 -m-3 rounded-xl hover:bg-white/5 transition-all border border-transparent focus:border-white/10 flex gap-3"
                          >
                            <span className="text-primary-blue">•</span>
                            {warning}
                          </li>
                        ))}
                      </ul>
                    </section>
                    <section>
                      <span className="text-xs font-bold uppercase tracking-[0.2em] text-white/40 block mb-6">{t.followUp}</span>
                      <p 
                        contentEditable 
                        suppressContentEditableWarning
                        onBlur={(e) => setPrescription({...prescription, FollowUp: e.currentTarget.textContent || ''})}
                        className="text-2xl font-bold outline-none p-3 -m-3 rounded-xl hover:bg-white/5 transition-all border border-transparent focus:border-white/10"
                      >
                        {prescription.FollowUp}
                      </p>
                    </section>
                  </div>
                </div>
              </div>

              <div className="flex flex-col md:flex-row justify-center gap-6 no-print">
                <button 
                  onClick={handleRecordAgain}
                  className="px-10 py-5 rounded-2xl bg-white/5 hover:bg-white/10 transition-all font-bold flex items-center justify-center gap-3 text-lg"
                >
                  <Mic size={22} />
                  <span>{t.recordAgain}</span>
                </button>
                <button 
                  onClick={showFinalPrescription}
                  className="px-16 py-5 rounded-2xl bg-primary-blue hover:bg-primary-blue/90 text-white font-bold transition-all flex items-center justify-center gap-3 shadow-2xl shadow-primary-blue/20 text-lg btn-glow"
                >
                  <CheckCircle2 size={24} />
                  <span>Approve & Finalize Prescription</span>
                </button>
              </div>
            </motion.div>
          )}

          {/* State: Final */}
          {currentState === 'final' && prescription && (
            <motion.div 
              key="final"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="py-12 app-section"
            >
              <div id="final-prescription-card" className="bg-white text-black p-12 rounded-3xl shadow-2xl max-w-4xl mx-auto border border-gray-200 font-sans">
                {/* Header */}
                <div className="border-b-4 border-navy pb-6 mb-8 flex justify-between items-center">
                  <div className="space-y-1">
                    <h1 className="text-3xl font-black uppercase tracking-tight text-navy">Dr. Ishaan Sharma (NMC/2026/8842)</h1>
                    <p className="text-lg font-bold text-navy/70">Clinical Summary & Prescription</p>
                  </div>
                  <div className="text-right no-print">
                    <button 
                      onClick={() => setSelectedLang(selectedLang === 'hindi' ? 'english' : 'hindi')}
                      className="bg-navy text-white px-4 py-2 rounded-xl text-xs font-bold tracking-widest hover:bg-navy/80 transition-all"
                    >
                      {selectedLang === 'hindi' ? 'Translate to English' : 'Translate to Hindi'}
                    </button>
                  </div>
                </div>

                {/* Patient Summary Row */}
                <div className="mb-10 bg-gray-50 p-6 rounded-2xl border border-gray-100 flex justify-between items-center text-navy font-bold">
                  <span>Patient: {patient.name}</span>
                  <span className="opacity-20">|</span>
                  <span>Age: {patient.age}</span>
                  <span className="opacity-20">|</span>
                  <span className={patient.allergies ? 'text-red-600' : ''}>
                    Allergies: {patient.allergies || 'None'}
                  </span>
                </div>

                {/* Medication Table */}
                <div className="mb-10 overflow-hidden rounded-2xl border border-gray-200 shadow-sm">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-navy text-white">
                        <th className="p-4 text-xs font-bold uppercase tracking-widest">Medicine</th>
                        <th className="p-4 text-xs font-bold uppercase tracking-widest">Dosage</th>
                        <th className="p-4 text-xs font-bold uppercase tracking-widest">Frequency</th>
                        <th className="p-4 text-xs font-bold uppercase tracking-widest">Duration</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {prescription.Drugs.map((drug, idx) => {
                        const getMappedTime = (frequency: string) => {
                          const f = frequency.toLowerCase();
                          if (f.includes('subah shaam') || f.includes('subah-shaam')) {
                            return selectedLang === 'hindi' ? 'दिन में दो बार (सुबह/शाम)' : 'Twice Daily (After Meals)';
                          }
                          if (f.includes('khali pet')) return selectedLang === 'hindi' ? 'खाली पेट' : 'Before Food';
                          if (f.includes('din mein teen baar')) return selectedLang === 'hindi' ? 'दिन में तीन बार' : 'Three times a day';
                          return frequency;
                        };

                        const getMappedDuration = (duration: string) => {
                          const d = duration.toLowerCase();
                          if (d.includes('3 din')) return selectedLang === 'hindi' ? '3 दिन' : '3 Days';
                          return duration;
                        };

                        return (
                          <tr key={idx} className={drug.Warning ? 'bg-red-50' : 'bg-white'}>
                            <td className="p-4">
                              <p className="font-bold text-navy">{drug.Name}</p>
                              {drug.Warning && <p className="text-[9px] font-bold text-red-600 uppercase mt-1">⚠️ {drug.Warning}</p>}
                            </td>
                            <td className="p-4 text-navy font-medium">{drug.Dosage}</td>
                            <td className="p-4 text-navy font-medium">{getMappedTime(drug.Frequency)}</td>
                            <td className="p-4 text-navy font-medium">{getMappedDuration(drug.Duration)}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Footer / Signature */}
                <div className="flex justify-between items-end pt-10 border-t-2 border-gray-100 italic text-gray-400 text-sm">
                  <p>Electronically generated by Speak Prescript AI</p>
                  <div className="text-right space-y-2">
                    <div className="w-48 h-1 bg-navy/20 mb-2" />
                    <p className="font-bold text-navy uppercase tracking-widest">Digital Signature</p>
                    <p className="text-xs">Dr. Ishaan Sharma</p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-6 justify-center mt-12 no-print">
                <button 
                  onClick={handlePrint}
                  className="px-10 py-5 rounded-2xl bg-white text-navy border-2 border-navy/10 hover:border-navy transition-all font-bold text-lg flex items-center gap-3 shadow-xl"
                >
                  <Printer size={24} />
                  <span>🖨️ Print PDF</span>
                </button>
                <button 
                  onClick={() => window.open(`https://wa.me/?text=Hello ${patient.name}, your prescription from Dr. Ishaan Sharma is ready.`, '_blank')}
                  className="px-10 py-5 rounded-2xl bg-green-600 hover:bg-green-700 text-white font-bold transition-all flex items-center gap-3 shadow-xl shadow-green-600/20 text-lg"
                >
                  <Phone size={24} />
                  <span>📩 WhatsApp</span>
                </button>
                <button 
                  onClick={resetToGateway}
                  className="px-10 py-5 rounded-2xl bg-navy hover:bg-navy/90 text-white font-bold transition-all text-lg"
                >
                  New Patient
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
